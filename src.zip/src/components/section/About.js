import React, { Component } from 'react'

export class About extends Component {
    render() {
        return (
            <div>
                <h2>About Component</h2>
            </div>
        )
    }
}

export default About
