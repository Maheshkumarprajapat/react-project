import React, { Component } from 'react'

export class Blog extends Component {
    render() {
        return (
            <div>
               <h2>Blog Component</h2> 
            </div>
        )
    }
}

export default Blog
