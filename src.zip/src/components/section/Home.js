import React, { Component } from 'react'

export class Home extends Component {
    render() {
        return (
            <div>
             <h2>Home Component</h2>   
            </div>
        )
    }
}

export default Home
