import React, { Component } from 'react'

export class Service extends Component {
    render() {
        return (
            <div>
                <h2>Service Component</h2>    
            </div>
        )
    }
}

export default Service
