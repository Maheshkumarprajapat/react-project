import React, { Component } from 'react'

export class logo extends Component {
    render() {
        return (
            <div className="logo">
            <span>Shiv</span>    
        </div>
        )
    }
}

export default logo
